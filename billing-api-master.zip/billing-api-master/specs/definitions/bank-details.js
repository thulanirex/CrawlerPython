module.exports = {
    name: String,
    account: String,
    branch: String,
    ifscCode: String
}
