module.exports = {
    id: 'string',
    code: 'string',
    name: 'string',
    symbol: String
}
