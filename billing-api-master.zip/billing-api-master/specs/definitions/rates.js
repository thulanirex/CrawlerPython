module.exports = {
    code: 'string', // price (if not there gets from parent)
    description: 'string',
    value: 'number',
    type: 'string',
    status: 'string'
}
