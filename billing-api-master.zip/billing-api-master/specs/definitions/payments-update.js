module.exports = {
    status: 'string',
    code: 'string'
}