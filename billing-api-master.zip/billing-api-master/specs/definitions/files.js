module.exports = {
    id: 'string',
    url: 'string',
    thumbnail: 'string'
}