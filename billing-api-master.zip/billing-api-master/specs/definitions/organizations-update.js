const bankDetails = require('./bank-details')

module.exports = {
    name: 'string',

    config: 'object',
    bankDetails: bankDetails,
    status: 'string'
}
