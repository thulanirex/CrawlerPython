const bankDetails = require('./bank-details')

module.exports = {
    code: 'string',
    name: 'string',
    config: 'object',
    bankDetails: bankDetails
}
