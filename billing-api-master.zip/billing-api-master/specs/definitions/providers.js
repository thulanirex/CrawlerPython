module.exports = {
    code: 'string',
    name: 'string',
    config: {},
    status: 'string'
}