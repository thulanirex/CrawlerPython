module.exports = {
    key: 'string',
    value: 'string',
    condition: 'string'
}