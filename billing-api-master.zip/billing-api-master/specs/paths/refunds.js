module.exports = [{
    url: '/',
    post: {
        parameters: ['x-role-key']
    }
}]