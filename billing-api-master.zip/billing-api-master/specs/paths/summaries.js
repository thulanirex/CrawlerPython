module.exports = [{
    url: '/{id}',
    get: { parameters: ['x-role-key'] }
}]