module.exports = [{
    url: '/{id}',
    get: { parameters: ['x-role-key'] },
    put: { parameters: ['x-role-key'] }
}]
