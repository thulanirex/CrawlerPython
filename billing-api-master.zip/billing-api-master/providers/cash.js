'use strict'

exports.success = async (payment, config) => {      //todo
    return
}

exports.refund = async (payment, config) => {      //todo
    return
}