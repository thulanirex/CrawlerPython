'use strict'

exports.success = async (payment, config) => {
    return                               // todo
}


exports.refund = async (payment, config) => {
    return                               // todo
}