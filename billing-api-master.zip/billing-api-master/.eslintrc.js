module.exports = {
    "extends": "standard",
    rules: {
        indent: [1, 4],
        "new-cap": [0]
    }
};
